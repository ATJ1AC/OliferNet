from fastapi import APIRouter
from src.controllers.user_controller import register
from src.dto.user_dto import UserCreate, UserResponse

router = APIRouter(prefix="/api/users", tags=["Users"])

@router.post("/", response_model=UserResponse)
def create_user(user: UserCreate):
    return register(user.username, user.password, user.country_id)