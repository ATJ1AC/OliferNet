from fastapi import FastAPI, status
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

from config.db import pool

app = FastAPI()

# Подключаем статические файлы
app.mount("/static", StaticFiles(directory="static"), name="static")

# --- Health check ---
@app.get("/")
def read_home():
    return {"message": "Go to /register or /login"}

@app.get("/api/health-check")
def health_check():
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
        return {"status": "OK"}
    except Exception:
        return {"error": "DB connection failed"}, status.HTTP_500_INTERNAL_SERVER_ERROR

# --- Главная страница ---
@app.get("/")
def read_index():
    return FileResponse("static/index.html")

@app.get("/register")
def show_register_page():
    return FileResponse("static/register.html")

@app.get("/login")
def show_login_page():
    return FileResponse("static/login.html")