# app.py

from dotenv import load_dotenv  # ✅ Импортируем здесь
import os

# Загрузка переменных окружения
load_dotenv()

# Проверка переменных окружения
print({
    "DB_HOST": os.getenv("DB_HOST"),
    "DB_PORT": os.getenv("DB_PORT"),
    "DB_USER": os.getenv("DB_USER"),
    "DB_PASSWORD": os.getenv("DB_PASSWORD"),
    "DB_NAME": os.getenv("DB_NAME")
})

# Подключение FastAPI
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles  # ✅ Теперь импортировано
from fastapi.responses import FileResponse

# Создаем приложение
app = FastAPI()

# Подключаем статические файлы
app.mount("/static", StaticFiles(directory="static"), name="static")

# --- Главная страница ---
@app.get("/")
def show_register_page():
    return FileResponse("static/index.html")

@app.get("/register")
def show_register_page():
    return FileResponse("static/register.html")

@app.get("/login")
def show_login_page():
    return FileResponse("static/login.html")

# --- Health check ---
@app.get("/api/health-check")
def health_check():
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
        return {"status": "OK"}
    except Exception as e:
        print("DB Error:", e)
        return {"error": "DB connection failed"}, 500