from fastapi import HTTPException
from src.repositories.user_repository import create_user

def register_user(username: str, password: str, country_id: int = None):
    if not username or not password:
        raise HTTPException(status_code=400, detail="Username and password are required")
    return create_user(username, password, country_id)