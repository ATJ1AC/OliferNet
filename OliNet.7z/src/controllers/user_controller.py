from src.services.user_service import register_user

def register(username: str, password: str, country_id: int = None):
    return register_user(username, password, country_id)