import bcrypt
from config.db import pool
from src.dto.user_dto import UserResponse

def get_password_hash(password):
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

def verify_password(plain_password, hashed_password):
    return bcrypt.checkpw(plain_password.encode(), hashed_password.encode())

def create_user(username: str, password: str, country_id: int = None):
    password_hash = get_password_hash(password)
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO users (username, password_hash, country_id)
                VALUES (%s, %s, %s)
                RETURNING id, username, country_id
                """,
                (username, password_hash, country_id)
            )
            row = cur.fetchone()
            return UserResponse(id=row[0], username=row[1], country_id=row[2])