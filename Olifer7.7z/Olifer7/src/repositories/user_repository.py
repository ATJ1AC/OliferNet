# src/repositories/user_repository.py

from sqlalchemy.orm import Session
from src.models.user import User  # Убедись, что модель определена
import bcrypt


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def get_user_by_username(db: Session, username: str) -> dict | None:
    user = db.query(User).filter(User.username == username).first()
    if user:
        return {
            "id": user.id,
            "username": user.username,
            "password_hash": user.hashed_password
        }
    return None


def user_exists(db: Session, username: str) -> bool:
    return get_user_by_username(db, username) is not None


def create_user(db: Session, username: str, password: str, country_id: int = None) -> dict:
    if user_exists(db, username):
        raise ValueError("Пользователь с таким именем уже существует")

    hashed = hash_password(password)
    db_user = User(
        username=username,
        hashed_password=hashed,
        country_id=country_id
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)

    return {
        "id": db_user.id,
        "username": db_user.username
    }


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return bcrypt.checkpw(plain_password.encode(), hashed_password.encode())