from abc import ABC, abstractmethod
from src.dto.country_dto import CountryCreate, CountryResponse

class BaseCountryRepository(ABC):
    @abstractmethod
    def create_country(self, name: str) -> CountryResponse:
        pass

    @abstractmethod
    def get_all_countries(self) -> list[CountryResponse]:
        pass