from src.services.auth_service import register_user, authenticate_user
from fastapi import HTTPException
from sqlalchemy.orm import Session

def register(username: str, password: str, country_id: int = None):
    try:
        return register_user(username, password, country_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail="Ошибка регистрации")

def login(username: str, password: str):
    user = authenticate_user(username, password)
    if not user:
        raise HTTPException(status_code=400, detail="Неверные учетные данные")
    return {"access_token": f"fake-jwt-token-for-{user['id']}"}

def get_current_user(db: Session):
    # Предположим, что у тебя есть способ получить текущего пользователя
    # Например, из сессии или куки
    # Для примера вернём тестового пользователя
    return {"username": "testuser"}