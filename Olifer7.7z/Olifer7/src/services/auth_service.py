# src/services/auth_service.py

from sqlalchemy.orm import Session
from src.repositories.user_repository import create_user, get_user_by_username, verify_password
from fastapi import HTTPException
import re
import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def validate_username(username: str):
    if not re.match(r'^[a-zA-Z0-9]+$', username):
        raise HTTPException(
            status_code=400,
            detail="Имя пользователя должно содержать только латинские буквы и цифры"
        )


def validate_password(password: str):
    if not re.match(r'^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]+$', password):
        raise HTTPException(
            status_code=400,
            detail="Пароль должен содержать минимум: 1 латинская буква, 1 цифра, 1 спецсимвол"
        )


def register_user(username: str, password: str, country_id: int, db: Session):
    if not username or not password:
        raise ValueError("Username and password are required")

    validate_username(username)
    validate_password(password)

    existing_user = get_user_by_username(db, username)
    if existing_user:
        raise HTTPException(status_code=400, detail="Пользователь с таким именем уже существует")

    return create_user(db, username, password, country_id)


def authenticate_user(username: str, password: str, db: Session):
    user = get_user_by_username(db, username)  # ✅ Теперь здесь всё верно
    if not user:
        return None
    if not verify_password(password, user.get("password_hash")):
        return None
    return {"message": "Login successful"}