# src/models/user.py

from sqlalchemy import Column, Integer, String, ForeignKey
from src.config.db import Base
from src.models.country import Country  # ✅ Теперь ORM знает о таблице country


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    country_id = Column(Integer, ForeignKey("country.id"), nullable=False)