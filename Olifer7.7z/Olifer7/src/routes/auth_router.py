# src/routes/auth_router.py

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from src.controllers.auth_controller import register, login
from src.config.db import get_db
from sqlalchemy.orm import Session

# Убрали префикс у роутера:
router = APIRouter(tags=["Auth"])

class RegisterRequest(BaseModel):
    username: str
    password: str
    country_id: int | None = None

class LoginRequest(BaseModel):
    username: str
    password: str

# Теперь этот маршрут будет доступен как /api/users
@router.post("/users")
def register_user_route( data: RegisterRequest, db: Session = Depends(get_db)):
    return register(data.username, data.password, data.country_id, db)

@router.post("/login")
def login_route(data: LoginRequest, db: Session = Depends(get_db)):
    return login(data.username, data.password, db)  # Передаём db

@router.get("/user/me")
def get_current_user_route(db: Session = Depends(get_db)):
    from src.controllers.auth_controller import get_current_user
    return get_current_user(db)