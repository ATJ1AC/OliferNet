# app.py

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from src.routes.auth_router import router as auth_router
from src.routes.user_router import router as user_router
from src.config.db import engine, Base
from src.models.user import User

# Создаем таблицы в БД (если их ещё нет)
Base.metadata.create_all(bind=engine)

app = FastAPI()

# Подключаем маршруты с префиксом /api
app.include_router(auth_router, prefix="/api")
app.include_router(user_router, prefix="/api")

# Статические файлы
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
def read_home():
    return FileResponse("static/index.html")

@app.get("/register")
def show_register_page():
    return FileResponse("static/register.html")

@app.get("/login")
def show_login_page():
    return FileResponse("static/login.html")

@app.get("/main")
def show_main_page():
    return FileResponse("static/home.html")