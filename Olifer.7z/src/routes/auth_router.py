from fastapi import APIRouter, Depends
from pydantic import BaseModel
from src.controllers.auth_controller import register, login
from pydantic import field_validator

router = APIRouter(prefix="/auth", tags=["Auth"])

class RegisterRequest(BaseModel):
    username: str
    password: str
    country_id: int | None = None

class LoginRequest(BaseModel):
    username: str
    password: str

@router.post("/login")
def login_route( data: LoginRequest):
    return login(data.username, data.password)

# ✅ Исправленный маршрут /users
@router.post("/users")
def register_user_route(data: RegisterRequest):  
    return register(data.username, data.password, data.country_id)

