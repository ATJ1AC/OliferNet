from src.repositories.user_repository import create_user

def register_user(username: str, password: str, country_id: int):
    return create_user(username, password, country_id)
def user_exists(username: str) -> bool:
    user = get_user_by_username(username)
    return user is not None

def register_user(username: str, password: str, country_id: int):
    if user_exists(username):
        raise Exception("Пользователь с таким именем уже существует")
    
    return create_user(username, password, country_id)