from repositories.db import get_country_repository

repo = get_country_repository()

def add_country(name: str):
    return repo.create_country(name)

def get_countries():
    return repo.get_all_countries()