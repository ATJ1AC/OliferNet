from src.repositories.user_repository import create_user, get_user_by_username, verify_password
from fastapi import HTTPException
import re

def register_user(username: str, password: str, country_id: int = None):
    if not username or not password:
        raise ValueError("Username and password are required")

    # Проверяем, существует ли пользователь
    existing_user = get_user_by_username(username)
    if existing_user:
        raise HTTPException(status_code=400, detail="Пользователь с таким именем уже существует")

    return create_user(username, password, country_id)


def authenticate_user(username: str, password: str):
    user = get_user_by_username(username)
    if not user:
        return None
    if not verify_password(password, user.get("password_hash")):
        return None
    return user




def validate_username(username: str):
    if not re.match(r'^[a-zA-Z0-9]+$', username):
        raise HTTPException(
            status_code=400,
            detail="Имя пользователя должно содержать только латинские буквы и цифры"
        )


def validate_password(password: str):
    if not re.match(r'^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]+$', password):
        raise HTTPException(
            status_code=400,
            detail="Пароль должен содержать минимум: 1 латинская буква, 1 цифра, 1 спецсимвол"
        )


def register_user(username: str, password: str, country_id: int = None):
    if not username or not password:
        raise ValueError("Username and password are required")

    validate_username(username)
    validate_password(password)

    existing_user = get_user_by_username(username)
    if existing_user:
        raise HTTPException(status_code=400, detail="Пользователь с таким именем уже существует")

    return create_user(username, password, country_id)