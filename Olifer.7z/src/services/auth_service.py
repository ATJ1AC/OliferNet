from src.repositories.user_repository import create_user, get_user_by_username, verify_password

def register_user(username: str, password: str, country_id: int = None):
    if not username or not password:
        raise ValueError("Username and password are required")
    return create_user(username, password, country_id)

def authenticate_user(username: str, password: str):
    user = get_user_by_username(username)
    if not user:
        return False
    if not verify_password(password, user["password_hash"]):
        return False
    return user