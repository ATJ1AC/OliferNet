import sqlite3
from src.repositories.base_country_repository import BaseCountryRepository
from src.dto.country_dto import CountryCreate, CountryResponse

class CountryRepository(BaseCountryRepository):
    def __init__(self):
        self.conn = sqlite3.connect("olifernet.db")
        self._initialize_table()

    def _initialize_table(self):
        with self.conn as conn:
            conn.execute("CREATE TABLE IF NOT EXISTS country (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)")

    def create_country(self, name: str) -> CountryResponse:
        with self.conn as conn:
            cur = conn.cursor()
            cur.execute("INSERT INTO country (name) VALUES (?)", (name,))
            conn.commit()
            return CountryResponse(id=cur.lastrowid, name=name)

    def get_all_countries(self) -> list[CountryResponse]:
        with self.conn as conn:
            cur = conn.cursor()
            cur.execute("SELECT id, name FROM country")
            rows = cur.fetchall()
            return [CountryResponse(id=row[0], name=row[1]) for row in rows]