# src/repositories/user_repository.py

import bcrypt
from src.config.db import get_db_connection

def hash_password(password):
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

def user_exists(username: str):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT 1 FROM users WHERE username = ?", (username,))
    return cur.fetchone() is not None

def create_user(username: str, password: str, country_id: int = None):
    if user_exists(username):
        raise ValueError("Пользователь с таким именем уже существует")

    conn = get_db_connection()
    hashed = hash_password(password)

    with conn:
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO users (username, password_hash, country_id) VALUES (?, ?, ?)",
            (username, hashed, country_id)
        )
        conn.commit()

    return {"id": cur.lastrowid, "username": username}
# Эта функция ДОЛЖНА быть
def get_user_by_username(username: str):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, username, password_hash FROM users WHERE username = ?", (username,))
    row = cur.fetchone()
    if not row:
        return None
    return {
        "id": row[0],
        "username": row[1],
        "password_hash": row[2]
    }

# Также убедись, что verify_password существует
def verify_password(plain_password: str, hashed_password: str):
    return bcrypt.checkpw(plain_password.encode(), hashed_password.encode())
def get_user_by_username(username: str):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, username, password_hash FROM users WHERE username = ?", (username,))
    row = cur.fetchone()
    if row:
        return {"id": row[0], "username": row[1], "password_hash": row[2]}
    return None