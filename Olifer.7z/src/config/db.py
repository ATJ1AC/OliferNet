from typing import Type
import sqlite3
import os

# Определяем тип БД из .env
DB_ENGINE = os.getenv("DB_ENGINE", "postgres").lower()

if DB_ENGINE == "postgres":
    from src.repositories.country_repository import CountryRepository
elif DB_ENGINE == "sqlite":
    from src.repositories.country_repository import CountryRepository
else:
    raise ValueError(f"Unsupported DB_ENGINE: {DB_ENGINE}")

def get_country_repository():
    return CountryRepository()
def get_db_connection():
    conn = sqlite3.connect("main.db")
    return conn