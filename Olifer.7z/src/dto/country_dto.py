from pydantic import BaseModel
from typing import Optional

class CountryCreate(BaseModel):
    name: str

class CountryResponse(CountryCreate):
    id: int