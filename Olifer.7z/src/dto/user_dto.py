from pydantic import BaseModel
from typing import Optional

class UserCreate(BaseModel):
    username: str
    password: str
    country_id: Optional[int] = None

class UserResponse(BaseModel):
    id: int
    username: str
    country_id: Optional[int]

    class Config:
        from_attributes = True