from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from src.routes.auth_router import router as auth_router
from src.routes.user_router import router as user_router



app = FastAPI()

# Подключаем маршруты
app.include_router(auth_router)
app.include_router(user_router)

from fastapi.staticfiles import StaticFiles
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
def read_home():
    return FileResponse("static/index.html")

@app.get("/register")
def show_register_page():
    return FileResponse("static/register.html")

@app.get("/login")
def show_login_page():
    return FileResponse("static/login.html")

@app.get("/main")
def show_main_page():
    return FileResponse("static/main.html")