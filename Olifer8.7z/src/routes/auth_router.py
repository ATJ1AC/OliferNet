# src/routes/auth_router.py

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from src.controllers.auth_controller import register, login
from src.services.auth_service import get_current_user as get_current_user_service
from src.config.db import get_db
from sqlalchemy.orm import Session

router = APIRouter(tags=["Auth"])

class RegisterRequest(BaseModel):
    username: str
    password: str
    country_id: int | None = None

class LoginRequest(BaseModel):
    username: str
    password: str

@router.post("/users")
def register_user_route( data: RegisterRequest, db: Session = Depends(get_db)):
    return register(data.username, data.password, data.country_id, db)

@router.post("/login")
def login_route(data: LoginRequest, db: Session = Depends(get_db)):
    result = login(data.username, data.password, db)

    # Сохраняем имя в куках через Set-Cookie
    from fastapi.responses import JSONResponse
    response = JSONResponse(content=result)
    response.set_cookie(key="username", value=result.get("username"), httponly=False, secure=False)
    return response

@router.get("/user/me")
def get_current_user_route(db: Session = Depends(get_db)):
    return get_current_user_service(db, "testuser")  # или передай реальное имя