from fastapi import APIRouter
from pydantic import BaseModel
from src.controllers.user_controller import create_user

router = APIRouter(prefix="/api", tags=["Users"])

class UserCreate(BaseModel):
    username: str
    password: str
    country_id: int

@router.post("/users")
def register(data: UserCreate):
    return create_user(data.username, data.password, data.country_id)