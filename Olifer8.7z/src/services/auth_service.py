# src/services/auth_service.py

from sqlalchemy.orm import Session
from src.repositories.user_repository import create_user, get_user_by_username, verify_password
from fastapi import HTTPException
import re
import logging
from typing import Union
from datetime import timedelta
from typing import Union, Any
import jwt
from fastapi import HTTPException, Depends
from sqlalchemy.orm import Session
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def validate_username(username: str):
    if not re.match(r'^[a-zA-Z0-9]+$', username):
        raise HTTPException(
            status_code=400,
            detail="Имя пользователя должно содержать только латинские буквы и цифры"
        )


def validate_password(password: str):
    if not re.match(r'^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]+$', password):
        raise HTTPException(
            status_code=400,
            detail="Пароль должен содержать минимум: 1 латинская буква, 1 цифра, 1 спецсимвол"
        )


def register_user(username: str, password: str, country_id: int, db: Session):
    if not username or not password:
        raise ValueError("Username and password are required")

    validate_username(username)
    validate_password(password)

    existing_user = get_user_by_username(db, username)
    if existing_user:
        raise HTTPException(status_code=400, detail="Пользователь с таким именем уже существует")

    return create_user(db, username, password, country_id)


def authenticate_user(db: Session, username: str, password: Union[str, None]):
    user = get_user_by_username(db, username)
    
    if not user:
        return None
    
    if password and not verify_password(password, user.get("password_hash")):
        return None
    
    return user


def get_current_user(db: Session, username: str):
    user = get_user_by_username(db, username)
    if not user:
        return None
    return user



SECRET_KEY = "your_secret_key_here"
ALGORITHM = "HS256"

def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt