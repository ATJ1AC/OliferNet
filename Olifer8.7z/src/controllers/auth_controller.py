from fastapi import Depends
from sqlalchemy.orm import Session
from src.config.db import get_db
from src.services.auth_service import register_user, authenticate_user, get_current_user as get_current_user_service



# src/controllers/auth_controller.py

from fastapi import Depends
from sqlalchemy.orm import Session
from src.config.db import get_db
from src.services.auth_service import register_user
from src.models.user import User


def register(username: str, password: str, country_id: int, db: Session = Depends(get_db)):
    return register_user(username, password, country_id, db)
    
def login(username: str, password: str, db: Session = Depends(get_db)):
    user = authenticate_user(db, username, password)
    if not user:
        raise HTTPException(status_code=401, detail="Неверные учетные данные")

    # Возвращаем ответ с куками
    response = {"message": "Login successful", "username": user["username"]}
    return response

def get_current_user(db: Session = Depends(get_db)):
    from fastapi import HTTPException

    test_username = "testuser"
    user = get_user_by_username(db, test_username)

    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    return {
        "username": user["username"],
        "balance": user.get("balance", 100)
    }