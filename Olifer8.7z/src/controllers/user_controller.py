from src.services.user_service import register_user

def create_user(username: str, password: str, country_id: int):
    return register_user(username, password, country_id)
from fastapi import HTTPException

def create_user(username: str, password: str, country_id: int):
    try:
        return register_user(username, password, country_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))